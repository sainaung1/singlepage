function chkblnk(eid, errid)
{
var x = document.getElementById(eid).value;
if (x == "") {
document.getElementById(errid).innerHTML = "Please enter this field";
} else {
document.getElementById(errid).innerHTML = "";
}
}
function chkAplha(event, err) {
if (!((event.which >= 65 && event.which <= 90) || (event.which >= 97 && event.which
<= 122) || event.which == 0 || event.which == 8)) {
document.getElementById(err).innerHTML = "invalid name format";
return false;
}
}
function chkeid()
{
var m = document.getElementById("e").value;
if (m == "") {
document.getElementById("error2").innerHTML = "Please enter your email address";
} else
{
var e = document.getElementById("e").value;

functionality

var atpos = e.indexOf("@");
var dotpos = e.lastIndexOf(".");
if (atpos < 4 || dotpos < atpos + 3)
{
document.getElementById("error2").innerHTML = "invalid email address";
} else
{
document.getElementById("error2").innerHTML = "";
}
}

}
function ValidateForm(form) {
ErrorText = "";
if ((form.gender[0].checked == false) && (form.gender[1].checked == false)) {
document.getElementById("error6").innerHTML = "Please select gender";
} else {
document.getElementById("error6").innerHTML = "";
} }